<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="index">
    <div class="login_registration_container">
        <p>Welcome to Library management System</p>
        <h1>admin Section</h1>
        <div class="login-registration-button">
            <a href="/admin_register.php">Register</a>
            <a href="/admin_login.php">Login</a>
        </div>
    </div>
</body>
</html>
