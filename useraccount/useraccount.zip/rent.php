<?php
session_start();
include 'config.php';

$username = $_SESSION['username'];

// Fetch rented books for the current user
$stmt = $conn->prepare("SELECT * FROM rented_books WHERE username = ?");
$stmt->bind_param('s', $username);
$stmt->execute();
$result = $stmt->get_result();
$rented_books = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rented Books</title>
</head>
<body>
    <h1>Rented Books</h1>

    <?php if (empty($rented_books)): ?>
        <p>No rented books.</p>
    <?php else: ?>
        <ul>
            <?php foreach ($rented_books as $book): ?>
                <li><?php echo htmlspecialchars($book['title']); ?> - Rented for <?php echo $book['rental_days']; ?> days</li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</body>
</html>
