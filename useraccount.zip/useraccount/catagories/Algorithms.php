<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Store</title>
    <link rel="stylesheet" href="/style.css"> <!-- Include your CSS file -->
</head>
<body>
<nav class="navbar">
    <div class="navbar_left">
        <a href="/test/index.php">Dashboard</a>
        <a href="book_type.php">Book Type</a>
        <a href="books_taken.php">Books Taken</a>
        <a href="add_book.php">Add New Book</a>
    </div>
    <div class="navbar_right">
        <a href="edit_profile.php">Edit Profile</a>
        <a href="logout.php">Logout</a>
    </div>
</nav>

<div class="dashboard_container">
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
</div>

<h1>Book Store</h1>

<div class="book-container">
    <div class="book">
        <img src="/books/Data Structures with Java.jpg" alt="Data Structures with Java">
        <p>Data Structures with Java</p>
        <div class="book-btn">
            <button onclick="addToCart('Data Structures with Java', '/books/Data Structures with Java.jpg')">Add to Cart</button>
            <button onclick="buyNow('Data Structures with Java', '/books/Data Structures with Java.jpg')">Buy</button>
        </div>
    </div>
    <div class="book">
        <img src="/books/Data Structures with Java.jpg" alt="Data Structures with Java">
        <p>Data Structures with Java</p>
        <div class="book-btn">
            <button onclick="addToCart('Data Structures with Java', '/books/Data Structures with Java.jpg')">Add to Cart</button>
            <button onclick="buyNow('Data Structures with Java', '/books/Data Structures with Java.jpg')">Buy</button>
        </div>
    </div>
    <div class="book">
        <img src="/books/Data Structures with Java.jpg" alt="Data Structures with Java">
        <p>Data Structures with Java</p>
        <div class="book-btn">
            <button onclick="addToCart('Data Structures with Java', '/books/Data Structures with Java.jpg')">Add to Cart</button>
            <button onclick="buyNow('Data Structures with Java', '/books/Data Structures with Java.jpg')">Buy</button>
        </div>
    </div>
    <!-- Add more books as needed -->
</div>

<a href="checkout.php"><button>Checkout</button></a> <!-- Add Checkout button -->

<!-- Modal Container -->
<div id="modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <p id="modal-message"></p>
    </div>
</div>

<script src="scripts.js"></script> <!-- Include your JavaScript file -->
</body>
</html>

