<?php
session_start();

// Mock user data. Replace with actual database query.
$books_taken = [
    ['title' => 'Book One', 'author' => 'Author One', 'due_date' => '2024-07-10'],
    ['title' => 'Book Two', 'author' => 'Author Two', 'due_date' => '2024-07-15'],
    ['title' => 'Book Three', 'author' => 'Author Three', 'due_date' => '2024-07-20']
];

function days_left($due_date) {
    $due_date = strtotime($due_date);
    $current_date = time();
    $datediff = $due_date - $current_date;
    return ceil($datediff / (60 * 60 * 24));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books Taken</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="index">
    <?php include 'includes/header.php'; ?>
    <h1>Books Taken</h1>
    <table class="books-table">
        <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Days Left to Return</th>
        </tr>
        <?php foreach ($books_taken as $book): ?>
            <tr>
                <td><?php echo htmlspecialchars($book['title']); ?></td>
                <td><?php echo htmlspecialchars($book['author']); ?></td>
                <td><?php echo days_left($book['due_date']); ?> days</td>
            </tr>
        <?php endforeach; ?>
    </table>
    <?php include 'includes/footer.php'; ?>
</body>
</html>
